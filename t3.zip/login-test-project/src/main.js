import Vue from 'vue'
import App from './App.vue'
import Router from './router'
import axios from 'axios'

Vue.config.productionTip = false

Vue.use(axios);

new Vue({
  router: Router,
  render: h => h(App),
  axios
}).$mount('#app')
