<template>
    <div id="login" style = "text-align:center;">
        <div id="child">
            <h1>Login</h1>
            <input type="text" id="usernamebox" name="username" v-model="input.username" placeholder="Username" />
            <br/>
            <br/>
            <input type="password" id="passwordbox" name="password" v-model="input.password" placeholder="Password" />
            <br/>
            <br/>
            <div v-show = "!infovisible" style = "text-align:center;">
                <button type="button" id="loginbutton"  v-on:click="login()">Login</button>
            </div>
            <div id = "intro" v-show = "infovisible" style = "text-align:left; margin-left: 10 em;">
                Current time: {{ timestamp }}<br/>
                Welcome {{currentusername}}<br/>
                Current path: {{currentdir}}<br/><br/>
                <button type="button" id="logoutbutton" v-on:click="logout()">Logout</button>
            </div>
            <br/><br/>{{message1}}
        </div>
    </div>
</template>

<script>
import axios from 'axios'
import path from 'path';
export default {
        name: 'Login',
        data() {
            return {
                input: {
                    username: "",
                    password: ""
                },
                message1: "",
                timestamp: "",
                currentusername: "",
                currentdir: "",
                infovisible: false
            }
        },
        methods: {
            login() {
                if(this.input.username == "" || this.input.password == "") {
                    this.message1 = "A username and password must be present";  
                } else {
                    //var payload = {username: this.input.username, password: this.input.password};
                    //var payload_json = JSON.stringify(payload);
                    axios.post('http://localhost:3200/api/user',
                    {username: this.input.username, password: this.input.password})
                    .then((response) => {
                        if (response.status == 200) {
                            if (response.data.statuscode == 0) {
                                this.infovisible = true;
                                const today = new Date();
                                // const date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
                                const time = today.getHours() + ":" + (today.getMinutes() < 10 ? '0' : '') + today.getMinutes() + ":" + (today.getSeconds() < 10 ? '0' : '') + today.getSeconds();
                                // const dateTime = date +' '+ time;
                                this.timestamp = time;
                                this.currentusername = this.input.username;
                                const cdirname = path.resolve();
                                this.currentdir = cdirname;                               
                                //this.message1=response.data;
                                this.message1="";
                            } else if (response.data.statuscode == 1) {
                                this.message1 = "unknown user";
                            } else {
                                this.message1 = "system error. Please try again";
                            }
                        } else {
                            this.message1 = "system error. Please try again"
                        }
                    })
                    .catch((e) => {this.message1=e})
                }
            },
            logout() {
                this.infovisible = false;
                this.input.username="";
                this.input.password="";
            }
        }
    }
</script>

<style scoped>
    #login {
        margin: auto;
        width: 200px;
        border: 1px solid #CCCCCC;
        background-color: #FFFFFF;        
        margin-top: 100px;
        padding: 20px;
        align-content: center;
        vertical-align: middle;
    }
</style>